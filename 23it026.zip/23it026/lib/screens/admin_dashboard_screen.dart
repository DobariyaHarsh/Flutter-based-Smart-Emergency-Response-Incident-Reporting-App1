import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/incident_model.dart';
import '../providers/incident_provider.dart';
import '../providers/app_provider.dart';
import '../utils/app_theme.dart';
import '../utils/helpers.dart';
import '../utils/constants.dart';
import '../widgets/incident_card.dart';
import '../widgets/stat_card.dart';
import 'incident_detail_screen.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  int _touchedIndex = -1;

  @override
  Widget build(BuildContext context) {
    final appProvider = context.watch<AppProvider>();
    final provider = context.watch<IncidentProvider>();

    if (!appProvider.isAdminMode) {
      return Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.primary.withOpacity(0.1),
                  border: Border.all(color: AppColors.primary.withOpacity(0.3)),
                ),
                child: const Icon(Icons.lock_outline,
                    color: AppColors.primary, size: 48),
              ),
              const SizedBox(height: 24),
              const Text('Admin Access Required',
                  style: TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 20,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              const Text('Use PIN: 1234 to unlock',
                  style: TextStyle(color: AppColors.textSecondary)),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () => appProvider.setAdminMode(true),
                style: ElevatedButton.styleFrom(
                    minimumSize: const Size(200, 48)),
                child: const Text('Enter Admin Mode'),
              ),
            ],
          ),
        ),
      );
    }

    final priorityDist = provider.priorityDistribution;
    final catDist = provider.categoryDistribution;
    final priorityColors = {
      IncidentPriority.critical: AppColors.critical,
      IncidentPriority.high: AppColors.high,
      IncidentPriority.medium: AppColors.medium,
      IncidentPriority.low: AppColors.low,
    };

    final pieSections = IncidentPriority.values
        .where((p) => (priorityDist[p] ?? 0) > 0)
        .toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border:
                  Border.all(color: AppColors.primary.withOpacity(0.4)),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.verified_user,
                    size: 14, color: AppColors.primary),
                SizedBox(width: 5),
                Text('ADMIN',
                    style: TextStyle(
                        color: AppColors.primary,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1)),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => appProvider.setAdminMode(false),
            tooltip: 'Exit Admin Mode',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Stats
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.4,
            children: [
              StatCard(
                label: 'Total Incidents',
                value: '${provider.totalIncidents}',
                icon: Icons.report_outlined,
                color: AppColors.info,
              ),
              StatCard(
                label: 'Active Cases',
                value: '${provider.activeIncidents}',
                icon: Icons.warning_amber_outlined,
                color: AppColors.warning,
              ),
              StatCard(
                label: 'Resolved',
                value: '${provider.resolvedIncidents}',
                icon: Icons.check_circle_outline,
                color: AppColors.success,
              ),
              StatCard(
                label: 'Critical',
                value: '${provider.criticalIncidents}',
                icon: Icons.crisis_alert,
                color: AppColors.critical,
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Priority Distribution Chart
          if (provider.totalIncidents > 0) ...[
            _SectionTitle(title: 'Priority Distribution'),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  SizedBox(
                    height: 160,
                    width: 160,
                    child: pieSections.isEmpty
                        ? const Center(
                            child: Text('No data',
                                style: TextStyle(color: AppColors.textMuted)))
                        : PieChart(
                            PieChartData(
                              sectionsSpace: 3,
                              centerSpaceRadius: 40,
                              touchData: PieTouchData(
                                touchCallback: (event, response) {
                                  setState(() {
                                    if (!event.isInterestedForInteractions ||
                                        response == null ||
                                        response.touchedSection == null) {
                                      _touchedIndex = -1;
                                      return;
                                    }
                                    _touchedIndex = response
                                        .touchedSection!.touchedSectionIndex;
                                  });
                                },
                              ),
                              sections: pieSections.asMap().entries.map((e) {
                                final i = e.key;
                                final p = e.value;
                                final count = priorityDist[p] ?? 0;
                                final isTouched = i == _touchedIndex;
                                return PieChartSectionData(
                                  color: priorityColors[p],
                                  value: count.toDouble(),
                                  title: isTouched ? '$count' : '',
                                  radius: isTouched ? 55 : 45,
                                  titleStyle: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14,
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: IncidentPriority.values.map((p) {
                        final count = priorityDist[p] ?? 0;
                        final color = priorityColors[p]!;
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              Container(
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: color,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                p.label,
                                style: const TextStyle(
                                    color: AppColors.textSecondary,
                                    fontSize: 12),
                              ),
                              const Spacer(),
                              Text(
                                '$count',
                                style: TextStyle(
                                    color: color,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Category bar chart
            _SectionTitle(title: 'Category Breakdown'),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              height: 200,
              child: BarChart(
                BarChartData(
                  alignment: BarChartAlignment.spaceAround,
                  maxY: (catDist.values.isEmpty
                          ? 1
                          : catDist.values.reduce((a, b) => a > b ? a : b))
                      .toDouble() +
                      2,
                  barTouchData: BarTouchData(enabled: true),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 24,
                        getTitlesWidget: (v, _) => Text(
                          '${v.toInt()}',
                          style: const TextStyle(
                              color: AppColors.textMuted, fontSize: 10),
                        ),
                      ),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 30,
                        getTitlesWidget: (value, _) {
                          final idx = value.toInt();
                          if (idx >= IncidentCategory.values.length) {
                            return const SizedBox.shrink();
                          }
                          return Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              IncidentCategory.values[idx].icon,
                              style: const TextStyle(fontSize: 14),
                            ),
                          );
                        },
                      ),
                    ),
                    rightTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false)),
                    topTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false)),
                  ),
                  gridData: FlGridData(
                    show: true,
                    getDrawingHorizontalLine: (_) => FlLine(
                        color: AppColors.border, strokeWidth: 0.5),
                    drawVerticalLine: false,
                  ),
                  borderData: FlBorderData(show: false),
                  barGroups: IncidentCategory.values.asMap().entries.map((e) {
                    final count = catDist[e.value] ?? 0;
                    return BarChartGroupData(
                      x: e.key,
                      barRods: [
                        BarChartRodData(
                          toY: count.toDouble(),
                          color: AppColors.primary.withOpacity(0.8),
                          width: 18,
                          borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(6)),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ),
          ],

          const SizedBox(height: 20),

          // Active incidents list
          _SectionTitle(title: 'Active Incidents (Priority Sorted)'),
          const SizedBox(height: 12),
          if (provider.incidents
              .where((i) => i.status != IncidentStatus.resolved)
              .isEmpty)
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.border),
              ),
              child: const Center(
                child: Text(
                  'No active incidents 🎉',
                  style: TextStyle(color: AppColors.textSecondary),
                ),
              ),
            )
          else
            ...provider.incidents
                .where((i) => i.status != IncidentStatus.resolved)
                .take(10)
                .map((incident) => IncidentCard(
                      incident: incident,
                      showAdminActions: true,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              IncidentDetailScreen(incidentId: incident.id),
                        ),
                      ),
                    )),

          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(
        color: AppColors.textPrimary,
        fontSize: 17,
        fontWeight: FontWeight.w700,
      ),
    );
  }
}
