import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/incident_model.dart';
import '../providers/incident_provider.dart';
import '../providers/app_provider.dart';
import '../utils/app_theme.dart';
import '../utils/constants.dart';
import '../utils/helpers.dart';
import 'incident_detail_screen.dart';

class ReportIncidentScreen extends StatefulWidget {
  const ReportIncidentScreen({super.key});

  @override
  State<ReportIncidentScreen> createState() => _ReportIncidentScreenState();
}

class _ReportIncidentScreenState extends State<ReportIncidentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  final _locationController = TextEditingController();
  final _nameController = TextEditingController();

  IncidentCategory _selectedCategory = IncidentCategory.medical;
  IncidentPriority _selectedPriority = IncidentPriority.medium;
  bool _isLoading = false;
  bool _useSimulatedGps = false;

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    _locationController.dispose();
    _nameController.dispose();
    super.dispose();
  }

  void _simulateGps() {
    setState(() {
      _useSimulatedGps = true;
      _locationController.text =
          kSimulatedLocations[DateTime.now().second % kSimulatedLocations.length];
    });
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final provider = context.read<IncidentProvider>();
      final appProvider = context.read<AppProvider>();

      final incident = await provider.addIncident(
        title: _titleController.text.trim(),
        description: _descController.text.trim(),
        category: _selectedCategory,
        priority: _selectedPriority,
        location: _locationController.text.trim(),
        latitude: _useSimulatedGps ? kDefaultLatitude : null,
        longitude: _useSimulatedGps ? kDefaultLongitude : null,
        reporterName: _nameController.text.trim(),
        isOnline: appProvider.isOnline,
      );

      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => _SuccessDialog(
            incidentId: incident.id,
            onViewDetails: () {
              Navigator.pop(context);
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                    builder: (_) =>
                        IncidentDetailScreen(incidentId: incident.id)),
              );
            },
            onDone: () => Navigator.pop(context),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Report Incident'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.maybePop(context),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.primary.withOpacity(0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline, color: AppColors.primary, size: 18),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Fill all required fields accurately. False reporting is a serious offence.',
                      style:
                          TextStyle(color: AppColors.textSecondary, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            _SectionLabel(label: 'REPORTER INFORMATION'),
            const SizedBox(height: 10),
            TextFormField(
              controller: _nameController,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(
                labelText: 'Your Name *',
                prefixIcon: Icon(Icons.person_outline, color: AppColors.textMuted),
              ),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Name is required' : null,
            ),

            const SizedBox(height: 20),
            _SectionLabel(label: 'INCIDENT DETAILS'),
            const SizedBox(height: 10),
            TextFormField(
              controller: _titleController,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(
                labelText: 'Incident Title *',
                prefixIcon: Icon(Icons.title, color: AppColors.textMuted),
                hintText: 'e.g. Person collapsed in lobby',
              ),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Title is required' : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _descController,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(
                labelText: 'Description *',
                prefixIcon: Icon(Icons.description_outlined, color: AppColors.textMuted),
                hintText: 'Describe what happened in detail...',
                alignLabelWithHint: true,
              ),
              maxLines: 4,
              validator: (v) => (v == null || v.trim().length < 10)
                  ? 'Provide at least 10 characters'
                  : null,
            ),

            const SizedBox(height: 20),
            _SectionLabel(label: 'CATEGORY'),
            const SizedBox(height: 10),
            _CategoryGrid(
              selected: _selectedCategory,
              onSelect: (c) => setState(() => _selectedCategory = c),
            ),

            const SizedBox(height: 20),
            _SectionLabel(label: 'PRIORITY LEVEL'),
            const SizedBox(height: 10),
            _PrioritySelector(
              selected: _selectedPriority,
              onSelect: (p) => setState(() => _selectedPriority = p),
            ),

            const SizedBox(height: 20),
            _SectionLabel(label: 'LOCATION'),
            const SizedBox(height: 10),
            TextFormField(
              controller: _locationController,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: InputDecoration(
                labelText: 'Location *',
                prefixIcon: const Icon(Icons.location_on_outlined,
                    color: AppColors.textMuted),
                hintText: 'Enter location or use GPS',
                suffixIcon: TextButton.icon(
                  onPressed: _simulateGps,
                  icon: const Icon(Icons.gps_fixed, size: 16),
                  label: const Text('GPS', style: TextStyle(fontSize: 12)),
                ),
              ),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Location is required' : null,
            ),

            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: _isLoading ? null : _submit,
              child: _isLoading
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : const Text('SUBMIT INCIDENT REPORT'),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: const TextStyle(
        color: AppColors.textMuted,
        fontSize: 11,
        fontWeight: FontWeight.w700,
        letterSpacing: 1.5,
      ),
    );
  }
}

class _CategoryGrid extends StatelessWidget {
  final IncidentCategory selected;
  final ValueChanged<IncidentCategory> onSelect;

  const _CategoryGrid({required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: 1.5,
      children: IncidentCategory.values.map((cat) {
        final isSelected = cat == selected;
        return GestureDetector(
          onTap: () => onSelect(cat),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            decoration: BoxDecoration(
              color: isSelected
                  ? AppColors.primary.withOpacity(0.2)
                  : AppColors.surfaceVariant,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected ? AppColors.primary : AppColors.border,
                width: isSelected ? 2 : 1,
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(cat.icon, style: const TextStyle(fontSize: 22)),
                const SizedBox(height: 4),
                Text(
                  cat.label,
                  style: TextStyle(
                    color: isSelected
                        ? AppColors.primary
                        : AppColors.textSecondary,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _PrioritySelector extends StatelessWidget {
  final IncidentPriority selected;
  final ValueChanged<IncidentPriority> onSelect;

  const _PrioritySelector({required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final colors = {
      IncidentPriority.low: AppColors.low,
      IncidentPriority.medium: AppColors.medium,
      IncidentPriority.high: AppColors.high,
      IncidentPriority.critical: AppColors.critical,
    };

    return Row(
      children: IncidentPriority.values.map((p) {
        final color = colors[p]!;
        final isSelected = p == selected;
        return Expanded(
          child: GestureDetector(
            onTap: () => onSelect(p),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: isSelected ? color.withOpacity(0.2) : AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected ? color : AppColors.border,
                  width: isSelected ? 2 : 1,
                ),
              ),
              child: Column(
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: color,
                      boxShadow: isSelected
                          ? [BoxShadow(color: color.withOpacity(0.6), blurRadius: 8)]
                          : null,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    p.label,
                    style: TextStyle(
                      color: isSelected ? color : AppColors.textMuted,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _SuccessDialog extends StatelessWidget {
  final String incidentId;
  final VoidCallback onViewDetails;
  final VoidCallback onDone;

  const _SuccessDialog({
    required this.incidentId,
    required this.onViewDetails,
    required this.onDone,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.success.withOpacity(0.15),
            ),
            child: const Icon(Icons.check_circle, color: AppColors.success, size: 48),
          ),
          const SizedBox(height: 16),
          const Text(
            'Incident Reported!',
            style: TextStyle(
              color: AppColors.textPrimary,
              fontSize: 20,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Your incident has been successfully submitted and logged.',
            style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.surfaceVariant,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              children: [
                const Text(
                  'INCIDENT ID',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 10, letterSpacing: 1),
                ),
                const SizedBox(height: 4),
                Text(
                  incidentId,
                  style: const TextStyle(
                    color: AppColors.primary,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: onViewDetails,
            style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 46)),
            child: const Text('View Details'),
          ),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: onDone,
            style: OutlinedButton.styleFrom(minimumSize: const Size(double.infinity, 46)),
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }
}
