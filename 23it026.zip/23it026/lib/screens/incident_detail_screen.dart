import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../models/incident_model.dart';
import '../providers/incident_provider.dart';
import '../providers/app_provider.dart';
import '../utils/app_theme.dart';
import '../utils/helpers.dart';
import '../utils/constants.dart';
import '../widgets/priority_badge.dart';
import '../widgets/status_chip.dart';

class IncidentDetailScreen extends StatelessWidget {
  final String incidentId;
  const IncidentDetailScreen({super.key, required this.incidentId});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<IncidentProvider>();
    final appProvider = context.watch<AppProvider>();
    final incident = provider.getById(incidentId);

    if (incident == null) {
      return Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(title: const Text('Incident Details')),
        body: const Center(
          child: Text('Incident not found',
              style: TextStyle(color: AppColors.textSecondary)),
        ),
      );
    }

    final priorityColor = AppColors.priorityColor(incident.priority);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 160,
            pinned: true,
            backgroundColor: AppColors.background,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new),
              onPressed: () => Navigator.pop(context),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      priorityColor.withOpacity(0.2),
                      AppColors.background,
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 60, 20, 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(incident.category.icon,
                                style: const TextStyle(fontSize: 28)),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                incident.title,
                                style: const TextStyle(
                                  color: AppColors.textPrimary,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            GestureDetector(
                              onTap: () {
                                Clipboard.setData(
                                    ClipboardData(text: incident.id));
                                showSnackBar(context, 'ID copied to clipboard');
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: AppColors.surfaceVariant,
                                  borderRadius: BorderRadius.circular(6),
                                  border: Border.all(color: AppColors.border),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      incident.id,
                                      style: const TextStyle(
                                        color: AppColors.textSecondary,
                                        fontSize: 11,
                                        fontFamily: 'monospace',
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    const Icon(Icons.copy,
                                        size: 11, color: AppColors.textMuted),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Status & Priority row
                  Row(
                    children: [
                      StatusChip(status: incident.status),
                      const SizedBox(width: 10),
                      PriorityBadge(priority: incident.priority),
                      const Spacer(),
                      if (!incident.isSynced)
                        Row(
                          children: const [
                            Icon(Icons.cloud_off,
                                size: 14, color: AppColors.warning),
                            SizedBox(width: 4),
                            Text('Offline',
                                style: TextStyle(
                                    color: AppColors.warning, fontSize: 12)),
                          ],
                        ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Info cards
                  _InfoCard(children: [
                    _InfoRow(
                        icon: Icons.person_outline,
                        label: 'Reported By',
                        value: incident.reporterName),
                    _InfoRow(
                        icon: Icons.category_outlined,
                        label: 'Category',
                        value: incident.category.label),
                    _InfoRow(
                        icon: Icons.access_time,
                        label: 'Reported At',
                        value: formatDateTime(incident.reportedAt)),
                    if (incident.updatedAt != null)
                      _InfoRow(
                          icon: Icons.update,
                          label: 'Last Updated',
                          value: formatDateTime(incident.updatedAt!)),
                  ]),
                  const SizedBox(height: 16),

                  _InfoCard(children: [
                    _InfoRow(
                        icon: Icons.location_on_outlined,
                        label: 'Location',
                        value: incident.location),
                    if (incident.latitude != null)
                      _InfoRow(
                          icon: Icons.gps_fixed,
                          label: 'GPS Coordinates',
                          value:
                              '${incident.latitude!.toStringAsFixed(4)}, ${incident.longitude!.toStringAsFixed(4)}'),
                  ]),
                  const SizedBox(height: 16),

                  // Description
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Description',
                            style: TextStyle(
                                color: AppColors.textMuted,
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1)),
                        const SizedBox(height: 8),
                        Text(
                          incident.description,
                          style: const TextStyle(
                              color: AppColors.textPrimary,
                              fontSize: 14,
                              height: 1.6),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Responder
                  _InfoCard(children: [
                    _InfoRow(
                      icon: Icons.person_pin_outlined,
                      label: 'Assigned Responder',
                      value: incident.assignedResponder ?? 'Not assigned yet',
                      valueColor: incident.assignedResponder != null
                          ? AppColors.textPrimary
                          : AppColors.textMuted,
                    ),
                  ]),

                  // Status Timeline
                  const SizedBox(height: 20),
                  const Text(
                    'STATUS TIMELINE',
                    style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.5),
                  ),
                  const SizedBox(height: 12),
                  _StatusTimeline(current: incident.status),

                  // Admin actions
                  if (appProvider.isAdminMode) ...[
                    const SizedBox(height: 24),
                    const Text(
                      'ADMIN ACTIONS',
                      style: TextStyle(
                          color: AppColors.textMuted,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.5),
                    ),
                    const SizedBox(height: 12),
                    _AdminActions(incident: incident),
                  ],

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final List<Widget> children;
  const _InfoCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: children
            .expand((child) => [child, const Divider(height: 1)])
            .toList()
          ..removeLast(),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color? valueColor;

  const _InfoRow({
    required this.icon,
    required this.label,
    required this.value,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: AppColors.textMuted),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        color: AppColors.textMuted, fontSize: 11)),
                const SizedBox(height: 2),
                Text(value,
                    style: TextStyle(
                        color: valueColor ?? AppColors.textPrimary,
                        fontSize: 14,
                        fontWeight: FontWeight.w500)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusTimeline extends StatelessWidget {
  final IncidentStatus current;
  const _StatusTimeline({required this.current});

  @override
  Widget build(BuildContext context) {
    final statuses = IncidentStatus.values;
    return Row(
      children: statuses.map((s) {
        final isDone = s.index <= current.index;
        final color = AppColors.statusColor(s);
        final isLast = s == statuses.last;
        return Expanded(
          child: Row(
            children: [
              Column(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isDone ? color.withOpacity(0.2) : AppColors.surfaceVariant,
                      border: Border.all(
                          color: isDone ? color : AppColors.border, width: 2),
                    ),
                    child: Icon(
                      isDone ? Icons.check : Icons.circle,
                      size: isDone ? 16 : 8,
                      color: isDone ? color : AppColors.textMuted,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    s.label,
                    style: TextStyle(
                      color: isDone ? color : AppColors.textMuted,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
              if (!isLast)
                Expanded(
                  child: Container(
                    height: 2,
                    color: statuses[s.index + 1].index <= current.index
                        ? AppColors.statusColor(statuses[s.index + 1])
                        : AppColors.border,
                    margin: const EdgeInsets.only(bottom: 22),
                  ),
                ),
            ],
          ),
        );
      }).toList(),
    );
  }
}

class _AdminActions extends StatelessWidget {
  final IncidentModel incident;
  const _AdminActions({required this.incident});

  @override
  Widget build(BuildContext context) {
    final provider = context.read<IncidentProvider>();

    return Column(
      children: [
        // Update Status
        _ActionButton(
          icon: Icons.update,
          label: 'Update Status',
          color: AppColors.info,
          onTap: () => _showStatusDialog(context, provider),
        ),
        const SizedBox(height: 10),
        _ActionButton(
          icon: Icons.person_add_outlined,
          label: incident.assignedResponder == null
              ? 'Assign Responder'
              : 'Change Responder',
          color: AppColors.success,
          onTap: () => _showResponderDialog(context, provider),
        ),
        const SizedBox(height: 10),
        _ActionButton(
          icon: Icons.flag_outlined,
          label: 'Change Priority',
          color: AppColors.warning,
          onTap: () => _showPriorityDialog(context, provider),
        ),
        const SizedBox(height: 10),
        _ActionButton(
          icon: Icons.delete_outline,
          label: 'Delete Incident',
          color: AppColors.error,
          onTap: () async {
            final confirmed = await showConfirmDialog(
              context,
              title: 'Delete Incident',
              message: 'This action cannot be undone.',
              confirmText: 'Delete',
              isDangerous: true,
            );
            if (confirmed && context.mounted) {
              await provider.deleteIncident(incident.id);
              Navigator.pop(context);
            }
          },
        ),
      ],
    );
  }

  void _showStatusDialog(BuildContext context, IncidentProvider provider) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(20),
            child: Text('Update Status',
                style: TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 18,
                    fontWeight: FontWeight.w700)),
          ),
          ...IncidentStatus.values.map((s) => ListTile(
                leading: CircleAvatar(
                  radius: 12,
                  backgroundColor: AppColors.statusColor(s).withOpacity(0.2),
                  child: Icon(Icons.circle,
                      size: 8, color: AppColors.statusColor(s)),
                ),
                title: Text(s.label,
                    style: const TextStyle(color: AppColors.textPrimary)),
                trailing: incident.status == s
                    ? const Icon(Icons.check, color: AppColors.primary)
                    : null,
                onTap: () async {
                  await provider.updateStatus(incident.id, s);
                  if (context.mounted) Navigator.pop(context);
                },
              )),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  void _showResponderDialog(BuildContext context, IncidentProvider provider) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(20),
            child: Text('Assign Responder',
                style: TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 18,
                    fontWeight: FontWeight.w700)),
          ),
          ...kResponders.map((r) => ListTile(
                leading: const CircleAvatar(
                  radius: 16,
                  backgroundColor: AppColors.surfaceVariant,
                  child: Icon(Icons.person, size: 16, color: AppColors.textSecondary),
                ),
                title: Text(r,
                    style: const TextStyle(color: AppColors.textPrimary)),
                trailing: incident.assignedResponder == r
                    ? const Icon(Icons.check, color: AppColors.primary)
                    : null,
                onTap: () async {
                  await provider.assignResponder(incident.id, r);
                  if (context.mounted) Navigator.pop(context);
                },
              )),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  void _showPriorityDialog(BuildContext context, IncidentProvider provider) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(20),
            child: Text('Change Priority',
                style: TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 18,
                    fontWeight: FontWeight.w700)),
          ),
          ...IncidentPriority.values.map((p) {
            final color = AppColors.priorityColor(p);
            return ListTile(
              leading: Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.2),
                  border: Border.all(color: color),
                ),
                child: Icon(Icons.circle, size: 10, color: color),
              ),
              title: Text(p.label,
                  style: TextStyle(color: color, fontWeight: FontWeight.w600)),
              trailing: incident.priority == p
                  ? const Icon(Icons.check, color: AppColors.primary)
                  : null,
              onTap: () async {
                await provider.updatePriority(incident.id, p);
                if (context.mounted) Navigator.pop(context);
              },
            );
          }),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 12),
            Text(label,
                style: TextStyle(
                    color: color,
                    fontSize: 14,
                    fontWeight: FontWeight.w600)),
            const Spacer(),
            Icon(Icons.arrow_forward_ios, color: color.withOpacity(0.5), size: 14),
          ],
        ),
      ),
    );
  }
}
