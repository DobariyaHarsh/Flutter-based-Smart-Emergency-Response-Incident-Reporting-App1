import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/incident_model.dart';
import '../providers/incident_provider.dart';
import '../utils/app_theme.dart';
import '../widgets/incident_card.dart';
import 'incident_detail_screen.dart';

class SearchFilterScreen extends StatefulWidget {
  const SearchFilterScreen({super.key});

  @override
  State<SearchFilterScreen> createState() => _SearchFilterScreenState();
}

class _SearchFilterScreenState extends State<SearchFilterScreen> {
  final _searchController = TextEditingController();
  IncidentStatus? _statusFilter;
  IncidentPriority? _priorityFilter;
  IncidentCategory? _categoryFilter;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _clearAll() {
    _searchController.clear();
    setState(() {
      _statusFilter = null;
      _priorityFilter = null;
      _categoryFilter = null;
    });
    context.read<IncidentProvider>().clearFilters();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<IncidentProvider>();

    // Apply filters locally
    var results = provider.incidents;
    final query = _searchController.text.toLowerCase().trim();
    if (query.isNotEmpty) {
      results = results.where((i) {
        return i.id.toLowerCase().contains(query) ||
            i.title.toLowerCase().contains(query) ||
            i.description.toLowerCase().contains(query) ||
            i.location.toLowerCase().contains(query) ||
            i.reporterName.toLowerCase().contains(query);
      }).toList();
    }
    if (_statusFilter != null) {
      results = results.where((i) => i.status == _statusFilter).toList();
    }
    if (_priorityFilter != null) {
      results = results.where((i) => i.priority == _priorityFilter).toList();
    }
    if (_categoryFilter != null) {
      results = results.where((i) => i.category == _categoryFilter).toList();
    }

    final hasFilters = query.isNotEmpty ||
        _statusFilter != null ||
        _priorityFilter != null ||
        _categoryFilter != null;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Search & Filter'),
        actions: [
          if (hasFilters)
            TextButton(
              onPressed: _clearAll,
              child: const Text('Clear All',
                  style: TextStyle(color: AppColors.primary)),
            ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(color: AppColors.textPrimary),
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Search by ID, title, location...',
                prefixIcon: const Icon(Icons.search, color: AppColors.textMuted),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, color: AppColors.textMuted),
                        onPressed: () {
                          _searchController.clear();
                          setState(() {});
                        },
                      )
                    : null,
              ),
            ),
          ),

          // Filter sections
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _FilterSection(
                  title: 'Status',
                  children: [
                    _FilterPill(
                      label: 'All',
                      isSelected: _statusFilter == null,
                      color: AppColors.textSecondary,
                      onTap: () => setState(() => _statusFilter = null),
                    ),
                    ...IncidentStatus.values.map((s) => _FilterPill(
                          label: s.label,
                          isSelected: _statusFilter == s,
                          color: AppColors.statusColor(s),
                          onTap: () => setState(() =>
                              _statusFilter = _statusFilter == s ? null : s),
                        )),
                  ],
                ),
                const SizedBox(height: 12),
                _FilterSection(
                  title: 'Priority',
                  children: [
                    _FilterPill(
                      label: 'All',
                      isSelected: _priorityFilter == null,
                      color: AppColors.textSecondary,
                      onTap: () => setState(() => _priorityFilter = null),
                    ),
                    ...IncidentPriority.values.map((p) => _FilterPill(
                          label: p.label,
                          isSelected: _priorityFilter == p,
                          color: AppColors.priorityColor(p),
                          onTap: () => setState(() =>
                              _priorityFilter = _priorityFilter == p ? null : p),
                        )),
                  ],
                ),
                const SizedBox(height: 12),
                _FilterSection(
                  title: 'Category',
                  children: [
                    _FilterPill(
                      label: 'All',
                      isSelected: _categoryFilter == null,
                      color: AppColors.textSecondary,
                      onTap: () => setState(() => _categoryFilter = null),
                    ),
                    ...IncidentCategory.values.map((c) => _FilterPill(
                          label: c.label,
                          isSelected: _categoryFilter == c,
                          color: AppColors.info,
                          emoji: c.icon,
                          onTap: () => setState(() =>
                              _categoryFilter = _categoryFilter == c ? null : c),
                        )),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                Text(
                  '${results.length} result${results.length == 1 ? '' : 's'}',
                  style: const TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 12,
                      fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          const Divider(height: 1),

          Expanded(
            child: results.isEmpty
                ? _EmptySearch(hasFilters: hasFilters)
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: results.length,
                    itemBuilder: (_, i) => IncidentCard(
                      incident: results[i],
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              IncidentDetailScreen(incidentId: results[i].id),
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _FilterSection extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _FilterSection({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title.toUpperCase(),
          style: const TextStyle(
            color: AppColors.textMuted,
            fontSize: 10,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: children),
      ],
    );
  }
}

class _FilterPill extends StatelessWidget {
  final String label;
  final bool isSelected;
  final Color color;
  final VoidCallback onTap;
  final String? emoji;

  const _FilterPill({
    required this.label,
    required this.isSelected,
    required this.color,
    required this.onTap,
    this.emoji,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.2) : AppColors.surfaceVariant,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: isSelected ? color : AppColors.border,
              width: isSelected ? 1.5 : 1),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (emoji != null) ...[
              Text(emoji!, style: const TextStyle(fontSize: 12)),
              const SizedBox(width: 4),
            ],
            Text(
              label,
              style: TextStyle(
                color: isSelected ? color : AppColors.textSecondary,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptySearch extends StatelessWidget {
  final bool hasFilters;
  const _EmptySearch({required this.hasFilters});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            hasFilters ? Icons.filter_list_off : Icons.search_off,
            size: 64,
            color: AppColors.textMuted,
          ),
          const SizedBox(height: 16),
          Text(
            hasFilters ? 'No matching incidents' : 'Start searching',
            style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 16,
                fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 8),
          Text(
            hasFilters
                ? 'Try adjusting your search or filters'
                : 'Enter keywords or apply filters above',
            style: const TextStyle(color: AppColors.textMuted, fontSize: 13),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
