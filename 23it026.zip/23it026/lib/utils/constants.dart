const List<String> kResponders = [
  'Dr. Sarah Mitchell',
  'Officer James Carter',
  'Firefighter Alex Rivera',
  'Paramedic Chris Johnson',
  'Security Guard Mike Thompson',
  'Nurse Emma Wilson',
  'Officer Lisa Chen',
  'Dr. David Park',
];

const List<String> kSimulatedLocations = [
  'Main Campus - Block A, Ground Floor',
  'Library Building - 2nd Floor',
  'Cafeteria - East Wing',
  'Parking Lot B - Zone 3',
  'Admin Block - Corridor 1',
  'Science Lab - Room 204',
  'Sports Complex - West Gate',
  'Hostel Block C - Room 112',
];

const double kDefaultLatitude = 28.6139;
const double kDefaultLongitude = 77.2090;

const String kAdminPin = '1234';
