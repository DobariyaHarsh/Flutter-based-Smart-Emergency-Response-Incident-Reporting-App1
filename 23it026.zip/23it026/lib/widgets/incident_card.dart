import 'package:flutter/material.dart';
import '../models/incident_model.dart';
import '../utils/app_theme.dart';
import '../utils/helpers.dart';
import 'priority_badge.dart';
import 'status_chip.dart';

class IncidentCard extends StatelessWidget {
  final IncidentModel incident;
  final VoidCallback? onTap;
  final bool showAdminActions;

  const IncidentCard({
    super.key,
    required this.incident,
    this.onTap,
    this.showAdminActions = false,
  });

  @override
  Widget build(BuildContext context) {
    final priorityColor = AppColors.priorityColor(incident.priority);
    final isCritical = incident.priority == IncidentPriority.critical;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border(
            left: BorderSide(color: priorityColor, width: 4),
            top: BorderSide(color: AppColors.border),
            right: BorderSide(color: AppColors.border),
            bottom: BorderSide(color: AppColors.border),
          ),
          boxShadow: isCritical
              ? [BoxShadow(color: priorityColor.withOpacity(0.15), blurRadius: 12, spreadRadius: 1)]
              : null,
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    incident.category.icon,
                    style: const TextStyle(fontSize: 20),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          incident.title,
                          style: const TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          incident.id,
                          style: const TextStyle(
                            color: AppColors.textMuted,
                            fontSize: 11,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ],
                    ),
                  ),
                  PriorityBadge(priority: incident.priority, compact: true),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                incident.description,
                style: const TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 13,
                  height: 1.4,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Icon(Icons.location_on_outlined,
                      size: 13, color: AppColors.textMuted),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      incident.location,
                      style: const TextStyle(
                          color: AppColors.textMuted, fontSize: 12),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  StatusChip(status: incident.status),
                  const Spacer(),
                  if (incident.assignedResponder != null) ...[
                    const Icon(Icons.person_outline,
                        size: 13, color: AppColors.textMuted),
                    const SizedBox(width: 4),
                    Text(
                      incident.assignedResponder!.split(' ').last,
                      style: const TextStyle(
                          color: AppColors.textMuted, fontSize: 12),
                    ),
                    const SizedBox(width: 8),
                  ],
                  const Icon(Icons.access_time,
                      size: 13, color: AppColors.textMuted),
                  const SizedBox(width: 4),
                  Text(
                    formatTimeAgo(incident.reportedAt),
                    style: const TextStyle(
                        color: AppColors.textMuted, fontSize: 12),
                  ),
                  if (!incident.isSynced) ...[
                    const SizedBox(width: 8),
                    const Icon(Icons.cloud_off,
                        size: 13, color: AppColors.warning),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
