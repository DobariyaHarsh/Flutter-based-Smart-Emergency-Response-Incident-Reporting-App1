import 'package:hive_flutter/hive_flutter.dart';
import '../models/incident_model.dart';

class HiveService {
  static const String _incidentBoxName = 'incidents';
  static Box<String>? _incidentBox;

  static Future<void> init() async {
    await Hive.initFlutter();
    _incidentBox = await Hive.openBox<String>(_incidentBoxName);
  }

  static Box<String> get _box {
    if (_incidentBox == null || !_incidentBox!.isOpen) {
      throw StateError('HiveService not initialized. Call init() first.');
    }
    return _incidentBox!;
  }

  static Future<void> saveIncident(IncidentModel incident) async {
    await _box.put(incident.id, incident.toJsonString());
  }

  static Future<void> deleteIncident(String id) async {
    await _box.delete(id);
  }

  static Future<void> updateIncident(IncidentModel incident) async {
    await _box.put(incident.id, incident.toJsonString());
  }

  static List<IncidentModel> getAllIncidents() {
    return _box.values
        .map((json) => IncidentModel.fromJsonString(json))
        .toList();
  }

  static IncidentModel? getIncident(String id) {
    final json = _box.get(id);
    if (json == null) return null;
    return IncidentModel.fromJsonString(json);
  }

  static Future<void> markAsSynced(String id) async {
    final incident = getIncident(id);
    if (incident != null) {
      await saveIncident(incident.copyWith(isSynced: true));
    }
  }

  static List<IncidentModel> getUnsyncedIncidents() {
    return getAllIncidents().where((i) => !i.isSynced).toList();
  }

  static Future<void> clearAll() async {
    await _box.clear();
  }
}
