import 'dart:convert';

enum IncidentCategory { medical, fire, security, accident, natural, other }

enum IncidentPriority { low, medium, high, critical }

enum IncidentStatus { reported, inProgress, resolved }

extension IncidentCategoryExtension on IncidentCategory {
  String get label {
    switch (this) {
      case IncidentCategory.medical:
        return 'Medical';
      case IncidentCategory.fire:
        return 'Fire';
      case IncidentCategory.security:
        return 'Security';
      case IncidentCategory.accident:
        return 'Accident';
      case IncidentCategory.natural:
        return 'Natural Disaster';
      case IncidentCategory.other:
        return 'Other';
    }
  }

  String get icon {
    switch (this) {
      case IncidentCategory.medical:
        return '🏥';
      case IncidentCategory.fire:
        return '🔥';
      case IncidentCategory.security:
        return '🔒';
      case IncidentCategory.accident:
        return '🚗';
      case IncidentCategory.natural:
        return '🌪️';
      case IncidentCategory.other:
        return '⚠️';
    }
  }
}

extension IncidentPriorityExtension on IncidentPriority {
  String get label {
    switch (this) {
      case IncidentPriority.low:
        return 'Low';
      case IncidentPriority.medium:
        return 'Medium';
      case IncidentPriority.high:
        return 'High';
      case IncidentPriority.critical:
        return 'Critical';
    }
  }

  int get sortOrder {
    switch (this) {
      case IncidentPriority.critical:
        return 0;
      case IncidentPriority.high:
        return 1;
      case IncidentPriority.medium:
        return 2;
      case IncidentPriority.low:
        return 3;
    }
  }
}

extension IncidentStatusExtension on IncidentStatus {
  String get label {
    switch (this) {
      case IncidentStatus.reported:
        return 'Reported';
      case IncidentStatus.inProgress:
        return 'In Progress';
      case IncidentStatus.resolved:
        return 'Resolved';
    }
  }
}

class IncidentModel {
  final String id;
  final String title;
  final String description;
  final IncidentCategory category;
  final IncidentPriority priority;
  final IncidentStatus status;
  final String location;
  final double? latitude;
  final double? longitude;
  final DateTime reportedAt;
  final String? assignedResponder;
  final bool isSynced;
  final String reporterName;
  final DateTime? updatedAt;

  IncidentModel({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.priority,
    required this.status,
    required this.location,
    this.latitude,
    this.longitude,
    required this.reportedAt,
    this.assignedResponder,
    required this.isSynced,
    required this.reporterName,
    this.updatedAt,
  });

  IncidentModel copyWith({
    String? id,
    String? title,
    String? description,
    IncidentCategory? category,
    IncidentPriority? priority,
    IncidentStatus? status,
    String? location,
    double? latitude,
    double? longitude,
    DateTime? reportedAt,
    String? assignedResponder,
    bool? isSynced,
    String? reporterName,
    DateTime? updatedAt,
  }) {
    return IncidentModel(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      priority: priority ?? this.priority,
      status: status ?? this.status,
      location: location ?? this.location,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      reportedAt: reportedAt ?? this.reportedAt,
      assignedResponder: assignedResponder ?? this.assignedResponder,
      isSynced: isSynced ?? this.isSynced,
      reporterName: reporterName ?? this.reporterName,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'category': category.index,
      'priority': priority.index,
      'status': status.index,
      'location': location,
      'latitude': latitude,
      'longitude': longitude,
      'reportedAt': reportedAt.toIso8601String(),
      'assignedResponder': assignedResponder,
      'isSynced': isSynced,
      'reporterName': reporterName,
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  factory IncidentModel.fromJson(Map<String, dynamic> json) {
    return IncidentModel(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      category: IncidentCategory.values[json['category'] as int],
      priority: IncidentPriority.values[json['priority'] as int],
      status: IncidentStatus.values[json['status'] as int],
      location: json['location'] as String,
      latitude: json['latitude'] as double?,
      longitude: json['longitude'] as double?,
      reportedAt: DateTime.parse(json['reportedAt'] as String),
      assignedResponder: json['assignedResponder'] as String?,
      isSynced: json['isSynced'] as bool,
      reporterName: json['reporterName'] as String,
      updatedAt: json['updatedAt'] != null
          ? DateTime.parse(json['updatedAt'] as String)
          : null,
    );
  }

  String toJsonString() => jsonEncode(toJson());

  factory IncidentModel.fromJsonString(String jsonStr) =>
      IncidentModel.fromJson(jsonDecode(jsonStr) as Map<String, dynamic>);
}
