import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/incident_model.dart';
import '../services/hive_service.dart';

const _uuid = Uuid();

class IncidentProvider extends ChangeNotifier {
  List<IncidentModel> _incidents = [];
  String _searchQuery = '';
  IncidentStatus? _filterStatus;
  IncidentPriority? _filterPriority;
  IncidentCategory? _filterCategory;

  List<IncidentModel> get incidents => _sortedIncidents(_incidents);
  String get searchQuery => _searchQuery;
  IncidentStatus? get filterStatus => _filterStatus;
  IncidentPriority? get filterPriority => _filterPriority;
  IncidentCategory? get filterCategory => _filterCategory;

  // Dashboard stats
  int get totalIncidents => _incidents.length;
  int get activeIncidents =>
      _incidents.where((i) => i.status != IncidentStatus.resolved).length;
  int get resolvedIncidents =>
      _incidents.where((i) => i.status == IncidentStatus.resolved).length;
  int get criticalIncidents =>
      _incidents.where((i) => i.priority == IncidentPriority.critical).length;

  Map<IncidentPriority, int> get priorityDistribution {
    final map = <IncidentPriority, int>{};
    for (final p in IncidentPriority.values) {
      map[p] = _incidents.where((i) => i.priority == p).length;
    }
    return map;
  }

  Map<IncidentCategory, int> get categoryDistribution {
    final map = <IncidentCategory, int>{};
    for (final c in IncidentCategory.values) {
      map[c] = _incidents.where((i) => i.category == c).length;
    }
    return map;
  }

  IncidentProvider() {
    loadIncidents();
  }

  void loadIncidents() {
    _incidents = HiveService.getAllIncidents();
    notifyListeners();
  }

  List<IncidentModel> _sortedIncidents(List<IncidentModel> list) {
    final sorted = List<IncidentModel>.from(list);
    sorted.sort((a, b) {
      final priorityCompare =
          a.priority.sortOrder.compareTo(b.priority.sortOrder);
      if (priorityCompare != 0) return priorityCompare;
      return b.reportedAt.compareTo(a.reportedAt);
    });
    return sorted;
  }

  List<IncidentModel> get filteredIncidents {
    var result = List<IncidentModel>.from(_incidents);

    if (_searchQuery.isNotEmpty) {
      final query = _searchQuery.toLowerCase();
      result = result.where((i) {
        return i.id.toLowerCase().contains(query) ||
            i.title.toLowerCase().contains(query) ||
            i.description.toLowerCase().contains(query) ||
            i.location.toLowerCase().contains(query);
      }).toList();
    }

    if (_filterStatus != null) {
      result = result.where((i) => i.status == _filterStatus).toList();
    }
    if (_filterPriority != null) {
      result = result.where((i) => i.priority == _filterPriority).toList();
    }
    if (_filterCategory != null) {
      result = result.where((i) => i.category == _filterCategory).toList();
    }

    return _sortedIncidents(result);
  }

  List<IncidentModel> get criticalActiveIncidents {
    return _sortedIncidents(_incidents
        .where((i) =>
            i.priority == IncidentPriority.critical &&
            i.status != IncidentStatus.resolved)
        .toList());
  }

  String _generateId() {
    final now = DateTime.now();
    final short = _uuid.v4().substring(0, 8).toUpperCase();
    return 'INC-${now.year}-$short';
  }

  Future<IncidentModel> addIncident({
    required String title,
    required String description,
    required IncidentCategory category,
    required IncidentPriority priority,
    required String location,
    double? latitude,
    double? longitude,
    required String reporterName,
    required bool isOnline,
  }) async {
    final incident = IncidentModel(
      id: _generateId(),
      title: title,
      description: description,
      category: category,
      priority: priority,
      status: IncidentStatus.reported,
      location: location,
      latitude: latitude,
      longitude: longitude,
      reportedAt: DateTime.now(),
      isSynced: isOnline,
      reporterName: reporterName,
    );
    await HiveService.saveIncident(incident);
    _incidents.add(incident);
    notifyListeners();
    return incident;
  }

  Future<void> updateStatus(String id, IncidentStatus status) async {
    final idx = _incidents.indexWhere((i) => i.id == id);
    if (idx == -1) return;
    final updated = _incidents[idx].copyWith(
      status: status,
      updatedAt: DateTime.now(),
    );
    await HiveService.updateIncident(updated);
    _incidents[idx] = updated;
    notifyListeners();
  }

  Future<void> assignResponder(String id, String responder) async {
    final idx = _incidents.indexWhere((i) => i.id == id);
    if (idx == -1) return;
    final updated = _incidents[idx].copyWith(
      assignedResponder: responder,
      updatedAt: DateTime.now(),
    );
    await HiveService.updateIncident(updated);
    _incidents[idx] = updated;
    notifyListeners();
  }

  Future<void> updatePriority(String id, IncidentPriority priority) async {
    final idx = _incidents.indexWhere((i) => i.id == id);
    if (idx == -1) return;
    final updated = _incidents[idx].copyWith(
      priority: priority,
      updatedAt: DateTime.now(),
    );
    await HiveService.updateIncident(updated);
    _incidents[idx] = updated;
    notifyListeners();
  }

  Future<void> deleteIncident(String id) async {
    await HiveService.deleteIncident(id);
    _incidents.removeWhere((i) => i.id == id);
    notifyListeners();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void setFilterStatus(IncidentStatus? status) {
    _filterStatus = status;
    notifyListeners();
  }

  void setFilterPriority(IncidentPriority? priority) {
    _filterPriority = priority;
    notifyListeners();
  }

  void setFilterCategory(IncidentCategory? category) {
    _filterCategory = category;
    notifyListeners();
  }

  void clearFilters() {
    _searchQuery = '';
    _filterStatus = null;
    _filterPriority = null;
    _filterCategory = null;
    notifyListeners();
  }

  IncidentModel? getById(String id) {
    try {
      return _incidents.firstWhere((i) => i.id == id);
    } catch (_) {
      return null;
    }
  }
}
