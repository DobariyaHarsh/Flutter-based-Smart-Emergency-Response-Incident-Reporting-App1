import 'package:flutter/material.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../services/hive_service.dart';

class AppProvider extends ChangeNotifier {
  bool _isAdminMode = false;
  bool _isOnline = true;
  List<ConnectivityResult> _connectivity = [];

  bool get isAdminMode => _isAdminMode;
  bool get isOnline => _isOnline;

  AppProvider() {
    _initConnectivity();
    _listenConnectivity();
  }

  Future<void> _initConnectivity() async {
    final result = await Connectivity().checkConnectivity();
    _connectivity = result;
    _isOnline = !result.contains(ConnectivityResult.none);
    notifyListeners();
  }

  void _listenConnectivity() {
    Connectivity().onConnectivityChanged.listen((result) {
      _connectivity = result;
      final wasOffline = !_isOnline;
      _isOnline = !result.contains(ConnectivityResult.none);
      notifyListeners();
      if (wasOffline && _isOnline) {
        _syncPendingIncidents();
      }
    });
  }

  Future<void> _syncPendingIncidents() async {
    final unsynced = HiveService.getUnsyncedIncidents();
    for (final incident in unsynced) {
      // Simulate sync - in production this would call an API
      await Future.delayed(const Duration(milliseconds: 200));
      await HiveService.markAsSynced(incident.id);
    }
  }

  void toggleAdminMode() {
    _isAdminMode = !_isAdminMode;
    notifyListeners();
  }

  void setAdminMode(bool value) {
    _isAdminMode = value;
    notifyListeners();
  }
}
