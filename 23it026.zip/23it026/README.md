# 🚨 RespondNow — Smart Emergency Response & Incident Reporting App

A Flutter-based mobile application for reporting, tracking, and managing emergency incidents with **offline-first** support.

---

## 📁 Project Structure

```
lib/
├── main.dart                         # App entry point
├── models/
│   └── incident_model.dart           # Incident data model + enums
├── providers/
│   ├── incident_provider.dart        # Incident state management (Provider)
│   └── app_provider.dart             # Connectivity + admin mode state
├── services/
│   └── hive_service.dart             # Hive local storage (offline-first)
├── utils/
│   ├── app_theme.dart                # Dark theme + color system
│   ├── constants.dart                # Responders list, locations, admin PIN
│   └── helpers.dart                  # Date formatting, snackbars, dialogs
├── screens/
│   ├── splash_screen.dart            # Animated splash (Screen 0)
│   ├── main_navigation_screen.dart   # Bottom nav shell
│   ├── home_screen.dart              # Dashboard (Screen 1)
│   ├── report_incident_screen.dart   # Report form (Screen 2)
│   ├── incident_list_screen.dart     # Incident list (Screen 3)
│   ├── incident_detail_screen.dart   # Detail view (Screen 4)
│   ├── admin_dashboard_screen.dart   # Admin panel (Screen 5)
│   └── search_filter_screen.dart     # Search & filter (Screen 6)
└── widgets/
    ├── incident_card.dart            # Reusable incident card
    ├── priority_badge.dart           # Color-coded priority badge
    ├── status_chip.dart              # Status indicator chip
    └── stat_card.dart                # Dashboard stat card
```

---

## 🛠️ Setup Instructions

### Prerequisites
- Flutter SDK ≥ 3.4.0
- Dart SDK ≥ 3.4.0
- Android Studio / VS Code with Flutter extension

### Steps

1. **Create a new Flutter project** in this directory:
   ```bash
   flutter create --org com.emergency --project-name emergency_response_app .
   ```
   > ⚠️ This will create default files. The source files in `lib/` will be overwritten — make sure to keep this project's files.

2. **Replace** `pubspec.yaml` with the provided one (already done).

3. **Replace** `android/app/build.gradle` with the provided one (already done) — sets `minSdk 21`.

4. **Install dependencies:**
   ```bash
   flutter pub get
   ```

5. **Run the app:**
   ```bash
   flutter run
   ```

---

## ✨ Features

| Feature | Details |
|---|---|
| **Incident Reporting** | Title, description, category (6 types), priority (4 levels), location (manual + simulated GPS) |
| **Unique Incident ID** | Auto-generated format: `INC-YYYY-XXXXXXXX` |
| **Incident Tracking** | Status: Reported → In Progress → Resolved |
| **Admin Dashboard** | View all, update status, assign responders, change priority, delete |
| **Priority Sorting** | Critical → High → Medium → Low, then by time |
| **Charts** | Pie chart (priority distribution), bar chart (category breakdown) |
| **Search & Filter** | By keyword, ID, status, priority, category |
| **Offline First** | Hive local storage, sync flag, auto-sync on reconnection |
| **Color Coding** | 🔴 Critical / 🟠 High / 🟡 Medium / 🟢 Low |

---

## 🔐 Admin Access

- Navigate to the **Admin** tab in the bottom navigation
- Enter PIN: **`1234`**
- Admin can update statuses, assign responders, change priorities, and delete incidents

---

## 📦 Dependencies

| Package | Purpose |
|---|---|
| `provider` | State management |
| `hive` + `hive_flutter` | Local (offline) storage |
| `connectivity_plus` | Network detection + auto-sync |
| `uuid` | Unique incident ID generation |
| `intl` | Date/time formatting |
| `fl_chart` | Dashboard charts |
| `google_fonts` | Typography |

---

## 🎨 Color System

| Priority | Color |
|---|---|
| Critical | `#EF4444` (Red) |
| High | `#F97316` (Orange) |
| Medium | `#EAB308` (Yellow) |
| Low | `#22C55E` (Green) |

| Status | Color |
|---|---|
| Reported | `#3B82F6` (Blue) |
| In Progress | `#F97316` (Orange) |
| Resolved | `#22C55E` (Green) |
